SELECT product, formatt, barCode, pack, price, stock, min_stock, max_stock
FROM REFS
