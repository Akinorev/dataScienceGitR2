# -*- coding: utf-8 -*-
"""
Created on 2020

@author: Verónica Gómez, Carlos Gtande, Pablo Olmos.
"""


import spotipy
from spotipy.oauth2 import SpotifyClientCredentials
from spotipy import Spotify as sp
import networkx as nx
from networkx.readwrite import json_graph
import networkx.algorithms.community as nxComm
import json
import community
import matplotlib.pyplot as plt
from collections import Counter
import numpy as np
import wikipedia
import pandas as pd


## Credenciales definimos el objeto para las busquedas
client_credentials_manager = SpotifyClientCredentials(client_id='74d5d729caf649daad709a2130c57d9d',
client_secret='a51bc30643c8432f89706eb9c9dd2401')
sp = spotipy.Spotify(client_credentials_manager=client_credentials_manager) 



##Inicializamos el Grafo

g         = nx.Graph()
Grupo     ='Johann Sebastian Bach'

results   = sp.search(q='artist:' + Grupo, type='artist')
artist    = results['artists']['items'][0]
artist_uri=artist['uri']

results2  = sp.artist_top_tracks(artist['uri'])
items     = results2['tracks'][:1]
for track in items:
         print(track['name'])
         print(track['preview_url'])  
                 
g.add_node(artist['name'], uri=artist['uri'] ,popularity=artist['popularity'] 
, followers=artist['followers'], image=artist['images'][0]['url'] ,genero=artist['genres']
,url=artist['external_urls'] ,best=track['preview_url'])





def grafo(g,Grupo):
    
    results = sp.search(q='artist:' + Grupo, type='artist', limit=1)
    artist = results['artists']['items'][0]
    artist_uri=artist['uri']
    artist_name=artist['name']
    
    
    results2  = sp.artist_top_tracks(artist['uri'])
    items     = results2['tracks'][:1]
    for track in items:
         print(track['name'])
         print(track['preview_url'])  
     
    g.add_node(artist['name'], uri=artist['uri'] ,popularity=artist['popularity'] 
         , followers=artist['followers'], image=artist['images'][0]['url'] ,genero=artist['genres']
         ,url=artist['external_urls'] ,best=track['preview_url'])
   
    results=sp.artist_albums(artist['uri'], album_type='album', country='ES', limit=1)  
    albums = results['items']

    while results['next']:
        results = sp.next(results)
        #print(sp.next(results))
        albums.extend(results['items'])
        
    tracks=[]
    for album in albums[:50]:
         #print(album['name'])
         results = sp.album_tracks(album['id'])
         track = results['items']
         tracks.extend(track)
         
    listado=set()
    for track in tracks:        
         #print(track['name'])
         for artist in track['artists']:  
             if artist['uri'] != artist_uri :
                            artist = sp.artist(artist['uri'])
                            listado.add(artist['name'])
                            results2  = sp.artist_top_tracks(artist['uri'])
                            items     = results2['tracks'][:1] 
                            for track in items:
                                print(track['name'])
                                print(track['preview_url']) 
                            if artist['name'] not in g  and artist['popularity']>19 and artist['name'] !='Anonymous' :
                                ##aquí vamos a añadir el Top1 del artista                    
                                if  len(artist['images']) > 0:        
                                    g.add_node(artist['name'], name=artist['name'], popularity=artist['popularity'], followers=artist['followers'] , image=artist['images'][0]['url'],genero=artist['genres'],url=artist['external_urls'],best_song=track['name'],best=track['preview_url'])
                                else:                                                         
                                    g.add_node(artist['name'], name=artist['name'], popularity=artist['popularity'], followers=artist['followers'] ,genero=artist['genres'],url=artist['external_urls'],best_song=track['name'],best=track['preview_url'])  
                            try:
                                    g[artist['name']][artist_name]['freq'] += 1
                            except KeyError:
                                    g.add_edge(artist['name'], artist_name, freq=1)
                     
                     
    return listado
    
 
###Iteramos cíclos hasta un número de nodos importante


lista=grafo(g,'Johann Sebastian Bach')
lista=grafo(g,'Ludwig van Beethoven')
lista=grafo(g,'Wolfgang Amadeus Mozart')
lista=grafo(g,'Giuseppe Verdi')
lista=grafo(g,'Pyotr Ilyich Tchaikovsky')
lista=grafo(g,'Igor Stravinsky')
lista=grafo(g,'Gustav Mahler')
lista=grafo(g,'George Frideric Handel')
lista=grafo(g,'Antonio Vivaldi')
lista=grafo(g,'Franz Joseph Haydn')
lista=grafo(g,'Franz Schubert')
lista=grafo(g,'Frédéric Chopin')
lista=grafo(g,'Robert Schumann')
lista=grafo(g,'Johannes Brahms')
lista=grafo(g,'Richard Wagner')
lista=grafo(g,'Richard Strauss')
lista=grafo(g,'Gaetano Donizetti')
lista=grafo(g,'Gioachino Rossini')
lista=grafo(g,'Georges Bizet')
lista=grafo(g,'Franz Liszt')
lista=grafo(g,'Maurice Ravel')
lista=grafo(g,'Claude Debussy')
lista=grafo(g,'Nikolai Rimsky-Korsakov')
lista=grafo(g,'Sergei Rachmaninov')
lista=grafo(g,'Sergei Prokofiev')
lista=grafo(g,'Félix Mendelssohn')
lista=grafo(g,'Hector Berlioz')
lista=grafo(g,'Arcangelo Corelli')
lista=grafo(g,'Jean-Baptiste Lully')
lista=grafo(g,'Henry Purcell')
lista=grafo(g,'Claudio Monteverdi')
lista=grafo(g,'Christoph Willibald Gluck')
lista=grafo(g,'Niccolò Paganini')
lista=grafo(g,'Isaac Albéniz')
lista=grafo(g,'Jean Sibelius')
lista=grafo(g,'Antonín Dvořák')
lista=grafo(g,'Manuel de Falla')
lista=grafo(g,'Carl Orff')
lista=grafo(g,'Benjamin Britten')
lista=grafo(g,'Béla Bartók')


 
nombres=nx.get_node_attributes(g, 'image')
numm=nx.get_node_attributes(g, 'popularity')
temas=nx.get_node_attributes(g, 'best')
nombre_temas=nx.get_node_attributes(g, 'best_song')

print(nx.info(g))


#### JSON RAW
# Escribimos un JSON con los datos del grafo para la entrada en d3js
j = json_graph.node_link_data(g)
js = json.dumps(j, ensure_ascii=False, indent=1)
with open("C:/Users/Pablo/Desktop/Grafos_Redes_Sociales/PRACTICA/salida_grafo_spotify_total.json", "w", encoding='utf-8') as file:
    file.write(js)
     

#### SEGUNDA PARTE DETECCION DE COMUNIDADES
    

#Visualización de redes de gran tamaño
#• Los blogs representan 9 partidos políticos, que se incluyen como atributos de losvértices.
#• Utilizamos el layout de Kamada-Kawa
#Por ejemplo, VxOrd [3] es un paquete de visualización de Sandia Labs.
#– Versión mejorada de la metodología spring-embedder.   

### ELIMINAMOS NODOS EN FUNCIÓN DE SU DEGREE

g.degree()
remove = [node for node,degree in g.degree() if degree <4]
remove
g.remove_nodes_from(remove)

### Info del Grafo
print(nx.info(g))


nx.draw_networkx(g)

## COmmunity Versión Larga

def modularity(communities: dict, graph: nx.Graph):
    inc = dict([])
    deg = dict([])
    links = graph.size()
    for node in graph:
        com = communities[node]
        deg[com] = deg.get(com, 0.) + graph.degree[node]
        for neighbor in graph.neighbors(node):
            if communities[neighbor] == com:
                if neighbor == node:
                    inc[com] = inc.get(com, 0.) + 1.
                else:
                    inc[com] = inc.get(com, 0.) + 0.5
    mod = dict()
    for com in set(communities.values()):
        mod[com] = (inc.get(com, 0.) / links) - (deg.get(com, 0.) / (2 * links)) ** 2
    return mod


def join_communities(communities: dict, c1: int, c2: int):
    """
    Mueve todos los miembros de c2 a c1
    """
    copyCom = communities.copy()
    for node in copyCom:
        if copyCom[node] == c2:
            copyCom[node] = c1
    return copyCom

def find_communities(graph: nx.Graph):
    bestMod = -1
    bestCom = None
    # Inicialmente, cada nodo en una comunidad
    com = dict()
    comIdx = 0
    for node in graph:
        com[node] = comIdx
        comIdx += 1

    # Calculamos la modularidad de esta solucion
    mod = modularity(com, graph)
    bestMod = mod
    while len(set(com.values())) > 1:
        # Encontramos la de minima modularidad
        minCom = -1
        minMod = 1
        for c in mod:
            if mod[c] < minMod:
                minCom = c
                minMod = mod[c]
        print(str(minCom)+"\t"+str(minMod))
        bestLocalMod = None
        bestLocalCom = None
        for c in set(com.values()):
            if c == minCom:
                continue
            testCom = join_communities(com, minCom, c)
            testMod = modularity(testCom, graph)
            if not bestLocalMod or sum(testMod.values()) > sum(bestLocalMod.values()):
                bestLocalMod = testMod.copy()
                bestLocalCom = testCom.copy()
        com = bestLocalCom.copy()
        mod = bestLocalMod.copy()
        # print(bestLocalMod)
        if sum(bestLocalMod.values()) > sum(bestMod.values()):
            bestMod = bestLocalMod.copy()
            bestCom = bestLocalCom.copy()
    print("Best Communities:")
    print(bestCom)
    print("Modularity")
    print(bestMod)
    print(str((bestMod.keys()))+"\t"+str(sum(bestMod.values())))
    return bestCom


 
comunidad=find_communities(g)

##Asignamos las comunidades
nx.set_node_attributes(g,comunidad, 'community')





###MEDIDAS A INCLUIR EN EL JSON

#closeness
closeness = nx.closeness_centrality(g)
nx.set_node_attributes(g, closeness,'closeness')

#betweenness
betweenness = nx.betweenness_centrality(g)
nx.set_node_attributes(g, betweenness, 'betweenness')

#pagerank
pagerank = nx.pagerank(g)
nx.set_node_attributes(g,pagerank, 'pagerank')

#comunidades y edgebetwenness
#commGreedy = list(nxComm.greedy_modularity_communities(g))
#for c in commGreedy:
#    for node in c:
#        g.nodes[node]['community'] = idComm
#        g.nodes[node]['closeness'] = closeness[node]
#        g.nodes[node]['betweenness'] = betweenness[node]
#    idComm += 1
    
#incluímos el  edgebetwenness en los edges
edgebetwenness = nx.edge_betweenness(g)
for edge in edgebetwenness:
    g[edge[0]][edge[1]]['eb'] = edgebetwenness[edge]



#### segunda  PARTE VISUALIZACIÓN en Python

# Fruchterman Reingold
nx.draw(g, with_labels=False, node_size=150, node_color="skyblue", pos=nx.fruchterman_reingold_layout(g))
plt.title("fruchterman_reingold")
 
# Circular
nx.draw(g, with_labels=False, node_size=150, node_color="skyblue", pos=nx.circular_layout(g))
plt.title("circular")
 

# Spring
nx.draw(g, with_labels=False, node_size=150, node_color="skyblue", pos=nx.spring_layout(g))
plt.title("spring")

# kamada_kawai_layout
nx.draw_kamada_kawai(g)
plt.title("kamada_kawai")



### Tercera Parte recuperamos la Información de la Lista definitiva de compositores en la Wikipedia

base=list(g)
wikipedia.set_lang("en")
wiki_list=[]
for x in base  :
                try:
                    i = (wikipedia.search(x)[0])
                    print(i)                    
                    try:
                        wiki=wikipedia.summary(i,sentences=4)
                        wiki_list.append(wiki)                                     
                    except  wikipedia.exceptions.DisambiguationError as e:
                        wiki_list.append(e.options[0])
                    except wikipedia.exceptions.PageError as e:
                        print (e)
                        i   = 'null'
                        wiki= 'null'
                        wiki_list.append(wiki)                        
                except (IndexError):
                        i   = 'null'
                        wiki= 'null'
                        wiki_list.append(wiki)
                    
              

                   
#prueba= (base,wiki_list)
###pasamos a diccionario
dictionary = dict(zip(base, wiki_list))
nx.set_node_attributes(g,  dictionary,'wikipedia')


    

#### Guardar el Json
# Escribimos un JSON con los datos del grafo para la entrada en d3js
j = json_graph.node_link_data(g)
js = json.dumps(j, ensure_ascii=False, indent=1)
with open("C:/Users/Pablo/Desktop/Grafos_Redes_Sociales/PRACTICA/salida_grafo_spotify_short.json","w", encoding='utf-8') as file:
    file.write(js)



